import React, { useEffect, useState } from "react";
import {
  Container,
  TextField,
  Button,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  Checkbox,
  Typography,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axios from "axios";

function Task() {
  const [tasks, setTasks] = useState([]);
  const [taskTitle, setTaskTitle] = useState("");
  const [taskDescription, setTaskDescription] = useState("");

  const handleTaskTitleChange = (event) => {
    setTaskTitle(event.target.value);
  };

  const handleTaskDescriptionChange = (event) => {
    setTaskDescription(event.target.value);
  };
  useEffect(() => {
    apiCallBack();
  }, []); // Provide an empty dependency array

  const apiCallBack = async () => {
    try {
      const task = await axios.get("http://localhost:4000/allrecord");
      console.log(task.data.tasks[0].title);
      setTasks([...task.data.tasks]);
    } catch (error) {
      console.error("Error calling API:", error);
    }
  };

  const handleAddTask = async () => {
    try {
      if (taskTitle.trim() !== "" && taskDescription.trim() != "") {
        await axios.post("http://localhost:4000/", {
          taskTitle,
          taskDescription,
          iscompleted: false,
        });
        toast("🦄 success inserted", {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });

        setTaskTitle("");
        setTaskDescription("");
      } else {
        toast.error("please enter required field", {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",
        });
      }
    } catch (error) {
      toast(error.message, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
  };

  const handleToggleCompletion = async (index) => {
    try {
      const updatedTasks = [...tasks];
      updatedTasks[index].completed = !updatedTasks[index].completed;
      console.log(updatedTasks[index].title);
      await axios.patch("http://localhost:4000/updatedtask", {
        taskTitle: updatedTasks[index].title,
        taskDescription: updatedTasks[index].description,
        iscompleted: updatedTasks[index].completed,
      });
      toast("🦄 success updated", {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    } catch (error) {
      toast(error.message, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
  };

  const handleDeleteTask = async (index) => {
    try {
      const updatedTasks = tasks.filter((_, i) => i === index);
      console.log(updatedTasks[0].title, updatedTasks[0].description);
      const url = `http://localhost:4000/deleteTask?taskTitle=${updatedTasks[0].title}&taskDescription=${updatedTasks[0].description}`;

      // Send the DELETE request
      await axios.delete(url);
      toast("🦄 success deleted", {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    } catch (error) {
      toast(error.message, {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "light",
      });
    }
  };

  return (
    <Container maxWidth="sm">
      <Typography variant="h4" component="h1" gutterBottom>
        Task Manager
      </Typography>
      <TextField
        label="Title"
        value={taskTitle}
        onChange={handleTaskTitleChange}
        fullWidth
        margin="normal"
      />
      <TextField
        label="Description"
        value={taskDescription}
        onChange={handleTaskDescriptionChange}
        fullWidth
        margin="normal"
      />
      <Button variant="contained" color="primary" onClick={handleAddTask}>
        Add Task
      </Button>
      <List>
        {tasks.map((task, index) => (
          <ListItem key={index} button>
            <ListItemText
              primary={task.title}
              secondary={task.description}
              style={{
                textDecoration: task.completed ? "line-through" : "none",
              }}
            />
            <ListItemSecondaryAction>
              <Checkbox
                edge="end"
                checked={task.completed}
                onChange={() => handleToggleCompletion(index)}
              />
              <IconButton edge="end" onClick={() => handleDeleteTask(index)}>
                <DeleteIcon />
              </IconButton>
            </ListItemSecondaryAction>
          </ListItem>
        ))}
      </List>
      <ToastContainer />
    </Container>
  );
}

export default Task;
