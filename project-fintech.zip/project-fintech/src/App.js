import logo from "./logo.svg";
import "./App.css";
import Task from "./Task";

function App() {
  return (
    <div className="App">
      <Task />
    </div>
  );
}

export default App;
